	<?php
		include "db.php";
		$about_select="SELECT * FROM about";
		$about_query=mysqli_query($connect,$about_select);
		$about_data=mysqli_fetch_assoc($about_query);
		$id=$about_data['id'];
		if(isset($_POST['update'])){
			
			$name=$_POST['name'];
			$title=$_POST['title'];
			$profile_des=$_POST['profile_des'];
			$profile=$_FILES['profile']['name'];
			$tmp=$_FILES['profile']['tmp_name'];
			if($profile){
				if(file_exists('img/'.$about_data['profile']) && !empty($about_data['profile'])){
					unlink('img/'.$about_data['profile']);
				}
			move_uploaded_file($tmp,'img/'.$profile);
			$update="UPDATE about SET name='$name',title='$title',profile_des='$profile_des',profile='$profile' WHERE id='$id'";
			$query=mysqli_query($connect,$update);
			if($query){
				header("location:http://localhost/dynamic%20portfolio%20wp/admin/index.php?page=about");
			}
			else{
				echo "wrong";
			}
		}}
		
		// social link
		$social_link_query=mysqli_query($connect,"SELECT * FROM social_link_manage");
		$social_data=mysqli_fetch_assoc($social_link_query);
		if(isset($_POST['update_link'])){
			$twitter=$_POST['twitter'];
			$facebook=$_POST['facebook'];
			$instagram=$_POST['instagram'];
			$skype=$_POST['skype'];
			$linkedin=$_POST['linkedin'];
			$youtube=$_POST['youtube'];
			$social_link_query=mysqli_query($connect,"UPDATE social_link_manage SET twitter='$twitter',facebook='$facebook',instagram='$instagram',skype='$skype',linkedin='$linkedin',youtube='$youtube'");
			
			// active and deactive part
			
		
			$a_twitter=$_POST['a_twitter'];
			$a_facebook=$_POST['a_facebook'];
			$a_instagram=$_POST['a_instagram'];
			$a_skype=$_POST['a_skype'];
			$a_linkedin=$_POST['a_linkedin'];
			$a_youtube=$_POST['a_youtube'];
			$a_social_active_query=mysqli_query($connect,"UPDATE social_link_active_deactive SET twitter='$a_twitter',facebook='$a_facebook',instagram='$a_instagram',skype='$a_skype',linkedin='$a_linkedin',youtube='$a_youtube'");
			header('location:http://localhost/dynamic%20portfolio%20wp/admin/index.php?page=about');
		}
		
		
	?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	label{
		font-size:18px;
		font-weight:bold;
	}
		input,textarea{
			display:block;
			width:50%;
			padding-left:10px;
			height:40px;
			margin:10px 0;
			box-sizing:border-box;
		}
		input,textarea:focus{
			outline-color:#05566E;
		}
		.table-bordered{
			width:50%;
		}
		@media only screen and (max-width:762px){
			input,textarea{
				width:100%;
			}
			.table-bordered{
			width:100%;
		}
		}
		input[type="submit"]{
			width:120px;
			background:#05566E;
			color:#fff;
			border:none;
			margin:20px 0;
		}
		input[type="submit"]:hover{
			background:#04617C;
		}
		td a,td a:hover{
			background:red;
			text-decoration:none;
			color:#fff;
			width:100px;
			height:40px;
			display:inline-block;
			text-align:center;
			line-height:40px;
			border-radius:4px;
		}
		
		.social_link{
			display:flex;
		}
		.social_link input{
		width:20px;
		height:17px;
		
		margin-left: 7px;
		margin-top: 6px;
		}
		
		
		
	</style>
</head>
<body>


	<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Update About </h1>
</div>
<div class="container-fluid py-2">
	<form action="" method="POST" enctype="multipart/form-data">
		<img src="img/<?=$about_data['profile'];?>" alt="" style="width:200px;height:200px;object-fit:cover;" /><br /><br />
		<label for="">Upload Image</label>
		<input type="file" name="profile" id=""  />
		<label for="">Profile Name</label>
		<input type="text" name="name" id="" value="<?php echo $about_data['name'];?>"/>
		<label for="">About Headline</label>
		<input type="text" name="title" id="" value="<?php echo $about_data['title'];?>"/>
		<label for="">About Description</label>
		<textarea name="profile_des" id="" cols="30" rows="10"><?php echo $about_data['profile_des'];?></textarea>
		<input type="submit" value="Submit" name="update" />
	</form>
			<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">More About--</h1>
</div><br />

<form action="" method="POST">
	<?php
		$more_about_query=mysqli_query($connect,"SELECT * FROM more_about");
		$more_about_data=mysqli_fetch_assoc($more_about_query);
		if(isset($_POST['more_update'])){
		$name=$_POST['name'];
		$dob=$_POST['dob'];
		$address=$_POST['address'];
		$zip_code=$_POST['zip_code'];
		$email=$_POST['email'];
		$website=$_POST['website'];
		$phone=$_POST['phone'];
		$more_about_update_query=mysqli_query($connect,"UPDATE more_about SET name='$name',dob='$dob',address='$address',zip_code='$zip_code',email='$email',website='$website',phone='$phone'");
		}
	?>
		<label for="">Name</label>
			<input type="text" name="name" id="" value="<?=$more_about_data['name'];?>"/>
		<label for="">Date Of Birth</label>
			<input type="text" name="dob" id="" value="<?=$more_about_data['dob'];?>" placeholder="mm/dd/yyyy"/>
		<label for="">Address</label>
			<input type="text" name="address" id="" value="<?=$more_about_data['address'];?>"/>
		<label for="">Zip Code</label>
			<input type="text" name="zip_code" id="" value="<?=$more_about_data['zip_code'];?>"/>
		<label for="">Email</label>
			<input type="email" name="email" id="" value="<?=$more_about_data['email'];?>"/>
		<label for="">Website</label>
			<input type="text" name="website" id="" value="<?=$more_about_data['website'];?>"/>
		<label for="">Phone</label>
			<input type="text" name="phone" id="" value="<?=$more_about_data['phone'];?>"/>
		<input type="submit" value="Submit" name="more_update" />
</form>















		<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Mange Social Link</h1>
</div><br />
	<form action="" method="POST">
		<?php
		$social_active_select=mysqli_query($connect,"SELECT * FROM social_link_active_deactive");
					$data=mysqli_fetch_assoc($social_active_select);
					
		
		?>
		<div class="social_link">
			<label for="">Twitter</label>
			<input type="checkbox" name="a_twitter" value="active" <?php if($data['twitter']=='active'){echo "checked";}?>>
		</div>
			<input type="text" name="twitter"  value="<?=$social_data['twitter'];?>"/>
		<div class="social_link">
			<label for="">Facebook</label>
			<input type="checkbox" name="a_facebook" value="active"  <?php if($data['facebook']=='active'){echo "checked";}?> >
		</div>
			<input type="text" name="facebook"  value="<?=$social_data['facebook'];?>"/>
		<div class="social_link">
			<label for="">Instagram</label>
			<input type="checkbox" name="a_instagram" value="active" <?php if($data['instagram']=='active'){echo "checked";}?>>
		</div>
			<input type="text" name="instagram"  value="<?=$social_data['instagram'];?>"/>
		<div class="social_link">
			<label for="">Skype</label>
			<input type="checkbox" name="a_skype" value="active" <?php if($data['skype']=='active'){echo "checked";}?>>
		</div>
			<input type="text" name="skype"  value="<?=$social_data['skype'];?>"/>
		<div class="social_link">
			<label for="">Linkedin</label>
			<input type="checkbox" name="a_linkedin" value="active" <?php if($data['linkedin']=='active'){echo "checked";}?>>
		</div>
			<input type="text" name="linkedin"  value="<?=$social_data['linkedin'];?>"/>
		<div class="social_link">
			<label for="">Youtube</label>
			<input type="checkbox" name="a_youtube" value="active" <?php if($data['youtube']=='active'){echo "checked";}?>>
		</div>
			<input type="text" name="youtube"  value="<?=$social_data['youtube'];?>"/>
		<input type="submit" value="Submit" name="update_link" />
	</form>







<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Mange Skillsbar</h1>
</div>

<?php
	if(isset($_POST['add_skill'])){
		$skill_name=$_POST['skill_name'];
		$skill_lable=$_POST['skill_label'];
		$skill_insert="INSERT INTO add_skill(skill_name,skill_label)VALUES('$skill_name','$skill_lable')";
		$skill_query=mysqli_query($connect,$skill_insert);
		if($skill_query){
			echo "<script>alert('Your Data Submited')</script>";
		}

		}
	
?>
<form action="" method="POST"><br />
	<label for="">Skill Name</label>
		<input type="text" name="skill_name" id="" value=""/>
	<label for="">Skill Level</label>
		<input type="text" name="skill_label" id="" value=""/>
	<input type="submit" value="Add Skill" name="add_skill" />
</form>
<br />
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Skill Name</th>
      <th scope="col">Skill Label</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
		<?php
					$skill_select="SELECT * FROM add_skill";
					$skill_select_query=mysqli_query($connect,$skill_select);
					while($skill_data=mysqli_fetch_array($skill_select_query)){
							$id=$skill_data['id'];
							$skill_name=$skill_data['skill_name'];
							$skill_label=$skill_data['skill_label'];
							echo "<tr> 
								<td>$skill_name</td>
								<td>$skill_label%</td>
								<td><a href='skill_delete.php?id=$id'><i class='fa fa-trash'></i> Delete</a></td>
							</tr>";
					}
					
						
			
		?>
  </tbody>
</table>
</div>














<br />
<br />
<br />
<br />
<br />
</body>
</html>
