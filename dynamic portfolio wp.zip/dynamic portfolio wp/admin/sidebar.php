<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/style.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="media_query/media.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
	<link rel="stylesheet" href="css/sidebar.css" />

			<style type="text/css">
@media only screen and (max-width:600px){
	.all_box{
		grid-template-columns:1fr!important;
	}
}			
			.all_box{
				display:grid;
				grid-template-columns:1fr 1fr 1fr;
				padding:20px;
				grid-gap:10px;
				width:100%;
			}
				.box{
					box-shadow:0 0 5px 1px;
					text-align:center;
					height:140px;
				}
				.box .fa{
					font-size:40px;
					padding:8px 0;
					color:#0F5BB1;
				}
				.box p{
					font-size:22px;
					color:#666;
				}
				.box h1{
					font-size:38px;
					font-family:arial;
					color:#282525;
				}
			
		</style>
			
</head>
<body>

<section class="main_div">
    <div class="side-bar sidebar" id="menu">
		<div class="profile"> 
			<img src="img/profile-img.jpg" alt="" />
		</div>
      <div class="menu">
        <div class="item"><a href="index.php?page=dashboard"><i class="fas fa-home"></i>Dashboard</a></div>
        <div class="item"><a href="index.php?page=about" ><i class="fa fa-user"></i>About</a></div>
        <div class="item"><a href="index.php?page=portfolio"><i class="fa fa-folder-open-o"></i>Portfolio</a></div>
        <div class="item"><a href="index.php?page=contact"><i class="fa fa-compress"></i> Contact</a></div>
       
      </div>
    </div>
 
 
 
 </section>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

<script>
function sidebars(){
	var menu=document.getElementById("menu");
	menu.classList.toggle("active");
	
}
</script>
  <script type="text/javascript">
    $(document).ready(function(){
      //jquery for toggle sub menus
      $('.sub-btn').click(function(){
        $(this).next('.sub-menu').slideToggle();
        $(this).find('.dropdown').toggleClass('rotate');
      });
    });
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
	<script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>
