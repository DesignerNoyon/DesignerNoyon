<br />
<div class="onheader"> 
    <ul>
    	<li><a href="#" style="color:#007BFF;"><i class="fa fa-dashboard" aria-hidden="true" ></i>  হোম </a></li>
    	<li><a href="#"><i class="fa fa-laptop"></i> ড্যাশবোর্ড  </a></li>
    </ul>
</div>

<div class="container-fluid" style="margin-top:30px;">
   <div class="row" >
        <div class="col-md-3">
            <div class="panel-primary">
               <div class="panel-heading py-0" style="background:#007BFF;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#28A745;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#FF6600;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
		
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#4463DC;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
       
        </div>
        


<br />
<br />


   <div class="row">
        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#9E00C1;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#FFC107;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#DC3545;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
		
		
		        <div class="col-md-3">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#10C100;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:40px;font-weight:bold;">250</div>
                            <div class="clearfix"></div>
                            <div class="pull-right">All Admin</div>
                        </div>
                    </div>
                </div>
                <a href="#">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Views All Admin</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
       
        </div>


</div>

<script src="https://kit.fontawesome.com/4054c17799.js"></script>
<br />
<br />
<br />