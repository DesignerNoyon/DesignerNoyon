<?php
	$connect=mysqli_connect("localhost","root","","dy_portfolio",);
?>