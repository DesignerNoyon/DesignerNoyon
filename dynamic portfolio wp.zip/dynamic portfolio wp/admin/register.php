<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
		form{
			width:470px;
			margin:4% auto;
			box-shadow: 0 0px 13px -4px #05566e;
			padding:14px;
			
		}
		form h1{
			text-align: center;
			font-size: 25px;
			font-weight: bold;
			color: #05566e;
			font-family: arial;
			text-transform: uppercase;
			padding-top:20px;
		}
		form input{
			width:100%;
			margin:6px 0;
			height:40px;
			padding-left:10px;
			
			
		}
		
		form input[type="submit"]{
			background: #05566e;
			color: #fff;
			border: none;
			font-size: 25px;
			font-weight: bold;
			letter-spacing: 1.5px;
			width: 148px;
			border-radius: 4px;
			height: 47px;
			margin-top:15px;
		}
		form input[type="submit"]:hover{
			background:#04617C;
		}
		form label{
			margin:2px 0;
			font-size:18px;
		}
		.success h1{
			background:green;
			color:#fff;
			font-weight:bold;
			font-size:20px;
			letter-spacing:1px;
			padding:10px;
		}
	</style>
</head>
<body>
	  <?php
		if(isset($_POST['register'])){
		$username=$_POST['username'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		$select="SELECT * FROM register WHERE username='$username'";
		$select_query=mysqli_query($connect,$select);
		$register_query=mysqli_query($connect,"INSERT INTO register(username,email,password)VALUES('$username','$email','$password')");
		if($register_query){
			$success="<h1>Register successful</h1>";
		}
		
		
	
	}
		  
		  ?>
		  <div class="success"><?php echo $success;?></div>
	<form method="POST">
		<h1>Register Now</h1>
		<label for="">User Name</label>
			<input type="text" name="username" required id="" />
		<label for="">Email</label>
			<input type="email" name="email" required id="" />
		<label for="">Password</label>
		<input type="text" name="password" id="" required />
		<input type="submit" value="Register" name="register" />
	</form>
</body>
</html>