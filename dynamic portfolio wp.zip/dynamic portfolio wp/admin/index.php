<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/style.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link href="../assets/vendor/icofont/icofont.min.css" rel="stylesheet">
	<link rel="stylesheet" href="media_query/media.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
	<link rel="stylesheet" href="css/sidebar.css" />

			<style type="text/css">
@media only screen and (max-width:600px){
	.all_box{
		grid-template-columns:1fr!important;
	}
}			
			.all_box{
				display:grid;
				grid-template-columns:1fr 1fr 1fr;
				padding:20px;
				grid-gap:10px;
				width:100%;
			}
				.box{
					box-shadow:0 0 5px 1px;
					text-align:center;
					height:140px;
				}
				.box .fa{
					font-size:40px;
					padding:8px 0;
					color:#0F5BB1;
				}
				.box p{
					font-size:22px;
					color:#666;
				}
				.box h1{
					font-size:38px;
					font-family:arial;
					color:#282525;
				}
			
		</style>
			
</head>
<body>
<?php
 if(isset($_GET['page'])){
                      $pages= $_GET['page'];
                  } 

	include "db.php";
		$about_select="SELECT * FROM about";
		$about_query=mysqli_query($connect,$about_select);
		$about_data=mysqli_fetch_assoc($about_query);
?>
<div class="container-fluid">
	<section class="header"> 
	    <div class="bars"> 
		   <i class="fa fa-bars" onclick="sidebars()"></i>
		   <span><i class="fa fa-users" style="color:#007BFF;font-size:18px"></i> Welcome: </span>
	    </div>
		<div class="bar">
		    <p><i class="fa fa-power-off" style="color:#007BFF;font-size:18px"></i> Logout</p>
		</div>
   </section>
<section class="main_div">
    <div class="side-bar sidebar" id="menu">
		<div class="profile"> 
			<img src="img/<?=$about_data['profile'];?>" alt="" />
		</div>
      <div class="menu">
        <div class="item"><a href="index.php?page=about" class="<?php error_reporting(0);if($pages=='about' || $pages==''){echo 'active';}else{echo '';}?>" ><i class="fa fa-user"></i>About</a></div>
        <div class="item"><a href="index.php?page=portfolio" class="<?php if($pages=='portfolio'){echo 'active';}else{echo '';}?>" ><i class="fa fa-folder-open-o"></i>Portfolio</a></div>
        <div class="item"><a href="index.php?page=service" class="<?php if($pages=='service'){echo 'active';}else{echo '';}?>" ><i class="fa fa-server"></i>Services</a></div>
        <div class="item"><a href="index.php?page=contact" class="<?php if($pages=='contact'){echo 'active';}else{echo '';}?>"><i class="fa fa-compress"></i> Contact</a></div>
        <div class="item"><a href="index.php?page=register" class="<?php if($pages=='register'){echo 'active';}else{echo '';}?>"><i class="fa fa-user-plus"></i> Register</a></div>
       
      </div>
    </div>
   
   <section class="site_content"> 
       <?php
                  session_start();
				  if(!isset($_SESSION['email'])){
					  header('location:../login.php');
				  }
                  if(isset($_GET['page'])){
                      $page=$_GET['page'].'.php';
                  } else {
                   $page='about.php';
                  }
                  
                  if(file_exists($page)){
                      require $page;
                  } else {
                      require '404.php';
                  }
                    
                    ?>
   </section>
 
 
 
 </section>
 </div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

<script>
function sidebars(){
	var menu=document.getElementById("menu");
	menu.classList.toggle("active");
	
}
</script>
  <script type="text/javascript">
    $(document).ready(function(){
      //jquery for toggle sub menus
      $('.sub-btn').click(function(){
        $(this).next('.sub-menu').slideToggle();
        $(this).find('.dropdown').toggleClass('rotate');
      });
    });
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
	<script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>
