<?php
	include "db.php";
	$id=$_GET['id'];
	$skill_delete_query=mysqli_query($connect,"DELETE FROM add_skill WHERE id='$id'");
	header("location:http://localhost/dynamic%20portfolio%20wp/admin/index.php?page=about");

?>