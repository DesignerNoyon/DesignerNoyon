	<?php
		include "db.php";
		if(isset($_POST['add_now'])){
			$p_img=$_FILES['p_img']['name'];
			$tmp=$_FILES['p_img']['tmp_name'];
			move_uploaded_file($tmp,'portfolio_img/'.$p_img);
			$p_type=$_POST['p_type'];
			$p_name=$_POST['p_name'];
			$p_link=$_POST['p_link'];
			$project_query=mysqli_query($connect,"INSERT INTO portfolio(p_img,p_type,p_name,p_link)VALUES('$p_img','$p_type','$p_name','$p_link')");
		}
		
		
	?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	label{
		font-size:18px;
		font-weight:bold;
	}
		input,select{
			display:block;
			width:50%;
			padding-left:10px;
			height:40px;
			margin:10px 0;
			box-sizing:border-box;
		}
		input,textarea:focus{
			outline-color:#05566E;
		}
		.table-bordered{
			width:50%;
		}
		@media only screen and (max-width:762px){
			input,textarea{
				width:100%;
			}
			.table-bordered{
			width:100%;
		}
		}
		input[type="submit"]{
			width:120px;
			background:#05566E;
			color:#fff;
			border:none;
			margin:20px 0;
		}
		input[type="submit"]:hover{
			background:#04617C;
		}
		
			td a,td a:hover{
			background:red;
			text-decoration:none;
			color:#fff;
			width:100px;
			height:40px;
			display:inline-block;
			text-align:center;
			line-height:40px;
			border-radius:4px;
		}
		
	</style>
</head>
<body>


<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Manage Portfolio</h1>
</div>
<div class="container-fluid py-2">
	<form action="" method="POST" enctype="multipart/form-data">
		<label for="">Project Image</label>
		<input type="file" name="p_img" id=""  />
		<label for="">Select Type</label>
		<select name="p_type" id="">
			<option value="static-website">Static Website</option>
			<option value="dynamic-website">Dynamic Website</option>
		</select>
		<label for="">Project Name</label>
		<input type="text" name="p_name" id="" value=""/>
		<label for="">Project Link</label>
		<input type="text" name="p_link" id="" value=""/>
		<input type="submit" value="Submit" name="add_now" />
	</form>
			

</div>
<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">All Portfolio</h1>
</div>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Project Name</th>
      <th scope="col">Project Type</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
		<?php
		
					$portfolio_select="SELECT * FROM portfolio";
					$portfolio_select_query=mysqli_query($connect,$portfolio_select);
					while($portfolio_data=mysqli_fetch_array($portfolio_select_query)){
							$id=$portfolio_data['id'];
							$p_name=$portfolio_data['p_name'];
							$p_type=$portfolio_data['p_type'];
							$p_img=$portfolio_data['p_img'];
							echo "<tr> 
								<td>$p_name</td>
								<td>$p_type</td>
								<td><a href='portfolio_delete.php?id=$id'><i class='fa fa-trash'></i> Delete</a></td>
							</tr>";
					}
					
						
			
		?>
		
  </tbody>
</table>
<br />
<br />
<br />
<br />
<br />
</body>
</html>
