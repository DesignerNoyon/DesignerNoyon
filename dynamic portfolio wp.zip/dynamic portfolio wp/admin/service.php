	<?php
		include "db.php";
		if(isset($_POST['add_now'])){
			$s_icon=$_POST['s_icon'];
			$s_name=$_POST['s_name'];
			$s_text=$_POST['des'];
			
			$service_query=mysqli_query($connect,"INSERT INTO  add_service(s_icon,s_name,s_text)VALUES('$s_icon','$s_name','$s_text')");
			if($service_query){
				header("location:http://localhost/dynamic%20portfolio%20wp/admin/index.php?page=service");
			}
		}
		
		
	?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	label{
		font-size:18px;
		font-weight:bold;
	}
		input,select{
			display:block;
			width:50%;
			padding-left:10px;
			height:40px;
			margin:10px 0;
			box-sizing:border-box;
		}
		input,textarea:focus{
			outline-color:#05566E;
		}
		.table-bordered{
			width:50%;
		}
		@media only screen and (max-width:762px){
			input,textarea{
				width:100%;
			}
			.table-bordered{
			width:100%;
		}
		}
		input[type="submit"]{
			width:120px;
			background:#05566E;
			color:#fff;
			border:none;
			margin:20px 0;
		}
		input[type="submit"]:hover{
			background:#04617C;
		}
		
			td a,td a:hover{
			background:red;
			text-decoration:none;
			color:#fff;
			width:100px;
			height:40px;
			display:inline-block;
			text-align:center;
			line-height:40px;
			border-radius:4px;
		}
		
	</style>
</head>
<body>


<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Manage Service</h1>
</div>
<div class="container-fluid py-2">
	<form action="" method="POST">
		<label for="">Service Icon(svg)</label>
		<input type="text" name="s_icon" id="" value=""/>
		<label for="">Service Name</label>
		<input type="text" name="s_name" id="" value=""/>
		<label for="">Service Description</label>
		<input type="text" name="des" id="" value=""/>
		<input type="submit" value="Submit" name="add_now" />
	</form>
			

</div>
<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">All Service</h1>
</div>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Service Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
		<?php
		
					$service_select="SELECT * FROM add_service";
					$service_select_query=mysqli_query($connect,$service_select);
					while($service_data=mysqli_fetch_array($service_select_query)){
							$id=$service_data['id'];
							$s_icon=$service_data['s_icon'];
							$s_name=$service_data['s_name'];
							echo "<tr> 
								<td><i class='$s_icon' style='font-size:20px;margin:8px 5px;background:#05566E;padding:8px 20px;display:inline;color:#fff;'></i>$s_name</td>
								<td><a href='service_delete.php?id=$id'><i class='fa fa-trash'></i> Delete</a></td>
							</tr>";
					}
					
						
			
		?>
		
  </tbody>
</table>
<br />
<br />
<br />
<br />
<br />
</body>
</html>
