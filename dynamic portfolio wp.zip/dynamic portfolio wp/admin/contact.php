	<?php
		include "db.php";
		if(isset($_POST['update'])){
			
			$location=$_POST['c_location'];
			$email=$_POST['c_email'];
			$call=$_POST['c_phone'];
			$map=$_POST['c_map'];
			$update="UPDATE `contact_info` SET `location`='$location',`email`='$email',`call`='$call',`map`='$map'";
			$query=mysqli_query($connect,$update);
		}
		$contact_data=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROm contact_info"));
		$location=$contact_data['location'];
		$email=$contact_data['email'];
		$call=$contact_data['call'];
		$map=$contact_data['map'];
		
		
	?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	label{
		font-size:18px;
		font-weight:bold;
	}
		input,textarea{
			display:block;
			width:50%;
			padding-left:10px;
			height:40px;
			margin:10px 0;
			box-sizing:border-box;
		}
		input,textarea:focus{
			outline-color:#05566E;
		}
		.table-bordered{
			width:50%;
		}
		@media only screen and (max-width:762px){
			input,textarea{
				width:100%;
			}
			.table-bordered{
			width:100%;
		}
		}
		input[type="submit"]{
			width:120px;
			background:#05566E;
			color:#fff;
			border:none;
			margin:20px 0;
		}
		input[type="submit"]:hover{
			background:#04617C;
		}
		td a,td a:hover{
			background:red;
			text-decoration:none;
			color:#fff;
			width:100px;
			height:40px;
			display:inline-block;
			text-align:center;
			line-height:40px;
			border-radius:4px;
		}
		
		.social_link{
			display:flex;
		}
		.social_link input{
		width:20px;
		height:17px;
		
		margin-left: 7px;
		margin-top: 6px;
		}
		
		
		
	</style>
</head>
<body>


	<div class="container-fluid p-2" style="background:#05566E"> 
	<h1 style="font-size:24px;color:#fff;font-weight:bold;">Update About </h1>
</div>
<div class="container-fluid py-2">
	<form method="POST">
		<label for="">Contact Location</label>
		<input type="text" name="c_location" id="" value="<?=$location;?>"/>
		<label for="">Contact Email</label>
		<input type="text" name="c_email" id="" value="<?=$email;?>"/>
		<label for="">Contact Phone</label>
		<input type="text" name="c_phone" id="" value="<?=$call;?>"/>
		<label for="">Location Maps</label>
		<input type="text" name="c_map" id="" value="<?=$map;?>"/>
		<input type="submit" value="Submit" name="update" />
	</form>

</div>














<br />
<br />
<br />
<br />
<br />
</body>
</html>
