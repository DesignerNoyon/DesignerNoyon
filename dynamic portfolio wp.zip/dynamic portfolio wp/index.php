<?php
	include "admin/db.php";
		$about_select="SELECT * FROM about";
		$about_query=mysqli_query($connect,$about_select);
		$about_data=mysqli_fetch_assoc($about_query);
		$id=$about_data['id'];
		$name=$about_data['name'];
		$title=$about_data['title'];
		$profile_des=$about_data['profile_des'];
		$profile=$about_data['profile'];
		// social_link_active_deactive
		$social_active_select=mysqli_query($connect,"SELECT * FROM social_link_active_deactive");
					$data=mysqli_fetch_assoc($social_active_select);
		
		// social link
		$social_link_query=mysqli_query($connect,"SELECT * FROM social_link_manage");
		$social_data=mysqli_fetch_assoc($social_link_query);		

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mystery Code - Blog</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js "></script>
    <script src="waypoints.min.js"></script>
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style type="text/css"> 
	.deactive{
		display:none!important;
	}

  </style>

</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="admin/img/<?=$profile;?>" alt="" class="img-fluid rounded-circle" style="object-fit:cover;width:130px;height:130px;border-radius:50%;">
        <h1 class="text-light"><a href="index.html"><?=$name;?></a></h1>
        <div class="social-links mt-3 text-center">
          <a href="<?=$social_data['twitter'];?>" class="twitter <?php if($data['twitter']!=='active'){echo 'deactive';}?>"><i class="bx bxl-twitter"></i></a>
          <a href="<?=$social_data['facebook'];?>" class="facebook <?php if($data['facebook']!=='active'){echo 'deactive';}?>"><i class="bx bxl-facebook"></i></a>
          <a href="<?=$social_data['instagram'];?>" class="instagram <?php if($data['instagram']!=='active'){echo 'deactive';}?>"><i class="bx bxl-instagram"></i></a>
          <a href="<?=$social_data['skype'];?>" class="google-plus <?php if($data['skype']!=='active'){echo 'deactive';}?>"><i class="bx bxl-skype"></i></a>
          <a href="<?=$social_data['linkedin'];?>" class="linkedin <?php if($data['linkedin']!=='active'){echo 'deactive';}?>"><i class="bx bxl-linkedin"></i></a>
          <a href="<?=$social_data['youtube'];?>" class="youtube <?php if($data['youtube']!=='active'){echo 'deactive';}?>"><i class="bx bxl-youtube"></i></a>

	

			
        </div>
      </div>

      <nav class="nav-menu">
        <ul>
          <li><a href="#about"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="#portfolio"><i class="bx bx-book-content"></i> Portfolio</a></li>
          <li><a href="#services"><i class="bx bx-server"></i> Services</a></li>
          <li><a href="#contact"><i class="bx bx-envelope"></i> Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->
      <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

    </div>
  </header><!-- End Header -->
  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <img src="admin/img/<?=$profile;?>" class="img-fluid" style="width: 100%;height: 400px;object-fit: cover;"alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content">
            <h3><?=$title;?></h3><br />
            <div class="row">
              <div class="col-lg-6">
			  <?php
			  	$more_about_query=mysqli_query($connect,"SELECT * FROM more_about");
				$more_about_data=mysqli_fetch_assoc($more_about_query);
			  ?>
                <ul>
                  <li><i class="icofont-rounded-right"></i> <strong>Name:</strong> <?=$more_about_data['name'];?></li>
                  <li><i class="icofont-rounded-right"></i> <strong>Date of birth:</strong> <?=$more_about_data['dob'];?></li>
                  <li><i class="icofont-rounded-right"></i> <strong>Address:</strong> <?=$more_about_data['address'];?></li>
                  <li><i class="icofont-rounded-right"></i> <strong>Zip code:</strong> <?=$more_about_data['zip_code'];?></li>
             
                  <li><i class="icofont-rounded-right"></i> <strong>Email:</strong> <?=$more_about_data['email'];?></li>
                  <li><i class="icofont-rounded-right"></i> <strong>Website:</strong> <?=$more_about_data['website'];?></li>
                  <li><i class="icofont-rounded-right"></i> <strong>Phone:</strong> <?=$more_about_data['phone'];?></li>
                </ul>
              </div>
            </div>
            <p class="about_content">
             <?=$profile_des;?>
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Skills Section ======= -->
        <div class="skills" id="body" >
				<?php
					include "admin/db.php";
					$skill_select="SELECT * FROM add_skill";
					$skill_select_query=mysqli_query($connect,$skill_select);
					while($skill_data=mysqli_fetch_array($skill_select_query)){
							$id=$skill_data['id'];
							$skill_name=$skill_data['skill_name'];
							$skill_label=$skill_data['skill_label'];
							echo "
							 <div class='skill'>
                    <div class='skill-name'>$skill_name</div>
                    <div class='skill-bar'>
                        <div class='skill-per' per='$skill_label'>$skill_label%</div>
                    </div>
                </div>";
					}
				?>
		
               
       
            </div><!-- End Skills Section -->

    

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">
 <div class="section-title">
          <h2>Portfolio <p>Latest Projects</p></h2>
          
        </div>
        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".static-website">Static Website</li>
              <li data-filter=".dynamic-website">Dynamic Website</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
			<?php
				$portfolio_query=mysqli_query($connect,"SELECT * FROM portfolio");
				while($portfolio_result=mysqli_fetch_assoc($portfolio_query)){
				
				$p_img=$portfolio_result['p_img'];
				$p_type=$portfolio_result['p_type'];
				$p_name=$portfolio_result['p_name'];
				$p_link=$portfolio_result['p_link'];
				?>			
			<div class='col-lg-5 col-md-6 portfolio-item <?=$p_type;?>'>
            <div class='portfolio-wrap' style="height:400px;">
              <img src='admin/portfolio_img/<?=$p_img;?>' class='img-fluid' alt='' >
              <div class='portfolio-links'>
                <a href='admin/portfolio_img/<?=$p_img?>' data-gall='portfolioGallery' class='venobox' title="<?=$p_type;?>"><i class='bx bx-plus'></i></a>
                <a href='portfolio-details.html' title='More Details'><i class='bx bx-link'></i></a>
              </div>
            </div>
          </div>
		  <?php
				}
			?>
          


        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Services <p>What I will do for you?</p></h2>
          
        </div>

        <div class="row">
				<?php
		
					$service_select="SELECT * FROM add_service";
					$service_select_query=mysqli_query($connect,$service_select);
					while($service_data=mysqli_fetch_array($service_select_query)){
						$id=$service_data['id'];
							$s_icon=$service_data['s_icon'];
							$s_name=$service_data['s_name'];
							$s_text=$service_data['s_text'];
							echo "
							   <div class='col-lg-4 col-md-6 icon-box' data-aos='fade-up'>
            <div class='icon'><i class='$s_icon'></i></div>
            <h4 class='title'><a href=''>$s_name</a></h4>
            <p class='description' style='text-align: justify;'>$s_text</p>
          </div>
							
							";
					}
						?>
							
						
		
     

      </div>
    </section><!-- End Services Section -->


    <!-- ======= Contact Section ======= -->
	<?php
		$contact_data=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROm contact_info"));
		$location=$contact_data['location'];
		$email=$contact_data['email'];
		$call=$contact_data['call'];
		$map=$contact_data['map'];
	?>
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Location:</h4>
                <p><?=$location;?></p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p><a href="mailto:<?=$email?>"><?=$email;?></a></p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Call:</h4>
                <p><?=$call;?></p>
              </div>
       
			  <iframe src="<?=$map;?>"  frameborder="0" style="border:0; width: 100%; height: 290px;"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
		  <?php
		if(isset($_POST['submit'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$sub=$_POST['sub'];
		$body=$_POST['body'];
		$contact_query=mysqli_query($connect,"INSERT INTO contact_msg(name,email,sub,body)VALUES('$name','$email','$sub','$body')");
		
	}
		  
		  ?>
            <form method="POST">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text"  name="name" class="form-control" required />
                  <div class="validate"></div>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" name="email" required/>
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="sub" required/>
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="body" rows="10" required></textarea>
                <div class="validate"></div>
              </div>
              <div class="text-center"><input type="submit" value="Submit" name="submit" /></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Webcoder Noyon</span></strong>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
	<script>
	<!-- skillbars -->
	
	$('.about').waypoint(function () {
                $('.skill-per').each(function () {
                var $this = $(this);
                var per = $this.attr('per');
                $this.css("width", per + '%');
                $({ animatedValue: 0 }).animate({ animatedValue: per }, {
                    duration: 2000,
					
                    step: function () {
                        $this.attr('per', Math.floor(this.animatedValue) + '%');
    
                    },
                    complete: function () {
                        $this.attr('per', Math.floor(this.animatedValue) + '%');
    
                    },
    
                });
            });
    },{offset:'40%'});
    <!-- disabled mouse right click -->
	     <!-- $(document).ready(function() { -->
          <!-- $("body").on("contextmenu", function(e) { -->
              <!-- return false; -->
            <!-- }); -->
        <!-- }); -->
		<!-- <!-- CSS /JS to prevent dragging  image --> -->
		 <!-- $('.disable_img').attr('draggable', false); -->
			<!-- document.getElementById('myImag').setAttribute('draggable', false); -->
    </script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>