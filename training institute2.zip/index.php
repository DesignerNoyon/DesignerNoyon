<?php
	session_start();
	if(!isset($_SESSION['login_form'])){
		header("location:login_form.php");
	}	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/style.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="media_query/media.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
	<link rel="stylesheet" href="css/sidebar.css" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" />


			<style type="text/css">
@media only screen and (max-width:600px){
	.all_box{
		grid-template-columns:1fr!important;
	}
}			
			.all_box{
				display:grid;
				grid-template-columns:1fr 1fr 1fr;
				padding:20px;
				grid-gap:10px;
				width:100%;
			}
				.box{
					box-shadow:0 0 5px 1px;
					text-align:center;
					height:140px;
				}
				.box .fa{
					font-size:40px;
					padding:8px 0;
					color:#0F5BB1;
				}
				.box p{
					font-size:22px;
					color:#666;
				}
				.box h1{
					font-size:38px;
					font-family:arial;
					color:#282525;
				}
	         .headierk {
	              width:100%;
	              height:50px;
	              background:#BDDDFF;
              }
             .headierk p{
             	color:black;
             	line-height:45px;
             	font-size:14px;
             	text-align:center;
             }		
               @media only screen and (max-width: 600px){
             		.headierk p{
             	        color:black;
             	        line-height:45px;
             	         font-size:12px;
             	         text-align:center;
                }	
  }
			
		</style>
			
</head>
<body>
<div class="container-fluid">
	<section class="header"> 
	    <div class="bars"> 
		   <i class="fa fa-bars" onclick="sidebars()"></i>
		   <span><i class="fa fa-users" style="color:#007BFF;font-size:18px"></i> ছাত্র/ছাত্রী ম্যানেজমেন্ট</span>
	    </div>
		<div class="bar">
		    <p><i class="fa fa-user" style="color:#007BFF;font-size:18px"></i> Welcome: Shoun</p>
		</div>
   </section>
<section class="main_div">
    <div class="side-bar sidebar" id="menu">

      <div class="menu">
        <div class="item"><a href="index.php?page=dashboard"><i class="fas fa-home"></i>ড্যাসবোর্ড</a></div>
        <div class="item">
          <a class="sub-btn"><i class="fas fa-users"></i> ছাত্র/ছাত্রী<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=add_student" class="sub-item"><i class="fas fa-angle-right"></i> ছাত্র/ছাত্রী তৈরি</a>
            <a href="index.php?page=student_list" class="sub-item"><i class="fas fa-angle-right"></i> ছাত্র/ছাত্রী লিস্ট</a>
            <a href="#" class="sub-item"><i class="fas fa-angle-right"></i>  ক্লাস অনুসারে ছাত্র/ছাত্রী</a>
			<a href="#" class="sub-item"><i class="fas fa-angle-right"></i> থানা অনুসারে ছাত্র/ছাত্রী</a>
          </div>
        </div>
		
	    <div class="item">
          <a class="sub-btn"><i class="fa fa-users"></i> শিক্ষক<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=add_teacher" class="sub-item"><i class="fas fa-angle-right"></i>  শিক্ষক তৈরি</a>
            <a href="index.php?page=list_teacher" class="sub-item"><i class="fas fa-angle-right"></i>  শিক্ষক তালিকা</a>
          </div>
        </div>	
		
 	    <div class="item">
          <a class="sub-btn"><i class="fas fa-users"></i> রেজাল্ট<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="#" class="sub-item"><i class="fas fa-angle-right"></i> মার্কস এনট্রি/আপডেট</a>
            <a href="#" class="sub-item"><i class="fas fa-angle-right"></i>রেজাল্ট শীট</a>
          </div>
        </div>   
		
     <div class="item">
          <a class="sub-btn"><i class="fas fa-users"></i> জমা/খরচী<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=pament_form" class="sub-item"><i class="fas fa-angle-right"></i>নতুন জমা</a>
            <a href="index.php?page=expense_form" class="sub-item"><i class="fas fa-angle-right"></i>নতুন খরছ</a>
          </div>
        </div>
		
     <div class="item">
          <a class="sub-btn"><i class="fa fa-credit-card" aria-hidden="true"></i>ভাউচার<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=payment_voucher" class="sub-item"><i class="fas fa-angle-right"></i>জমা ভাউচার</a>
            <a href="index.php?page=expense_vouchers" class="sub-item"><i class="fas fa-angle-right"></i>খরচের ভাউচার</a>
          </div>
        </div>	      
		
	<div class="item">
          <a class="sub-btn"><i class="fas fa-id-card"></i> আইডি কার্ড<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=id_card_list" class="sub-item"><i class="fas fa-angle-right"></i>আইডি কার্ড লিস্ট</a>
          </div>
      </div>	 
	  
      <div class="item">
          <a class="sub-btn"><i class="fas fa-users"></i>রিপোর্ট<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=student_add_report" class="sub-item"><i class="fas fa-angle-right"></i>ছাত্র/ছাত্রী র্ভতি রিপোর্ট</a>
			<a href="index.php?page=student_deposit_report" class="sub-item"><i class="fas fa-angle-right"></i>ছাত্র/ছাত্রী জমার রিপোর্ট</a>
			<a href="index.php?page=student_cost_report" class="sub-item"><i class="fas fa-angle-right"></i>ছাত্র/ছাত্রী খরচের রিপোর্ট</a>			
			<a href="#" class="sub-item"><i class="fas fa-angle-right"></i>খরচের খাতের রিপোর্ট</a>
          </div>
       </div>

      <div class="item">
          <a class="sub-btn"><i class="fas fa-users"></i>সেটিং<i class="fas fa-angle-right dropdown"></i></a>
          <div class="sub-menu">
            <a href="index.php?page=add_student" class="sub-item"><i class="fas fa-angle-right"></i>প্রতিষ্ঠানের তথ্য</a>
            <a href="index.php?page=student_list" class="sub-item"><i class="fas fa-angle-right"></i>পাসওয়ার্ড পরিবর্তন</a>
            <a href="#" class="sub-item"><i class="fas fa-angle-right"></i>জমার খাত তৈরি</a>
			<a href="#" class="sub-item"><i class="fas fa-angle-right"></i>শ্রেনী/ক্লাস তৈরি</a>
			<a href="#" class="sub-item"><i class="fas fa-angle-right"></i>ব্যাচ নং</a>
          </div>
       </div>
	   
      <div class="item">
          <a href="http://localhost/project/Website_project_demo/login_form.php"><i class="fas fa-users"></i>লগ-আউট<i class="fas fa-angle-right dropdown"></i></a>
       </div>
	   
	   <br /> <br />
	 
        </div>
     </div>
 </div>
   
   <section class="site_content"> 
       <?php
                  
                  if(isset($_GET['page'])){
                      $page=$_GET['page'].'.php';
                  } else {
                   $page='dashboard.php';
                  }
                  
                  if(file_exists($page)){
                      require $page;
                  } else {
                      require '404.php';
                  }
                    
                    ?>
         </section>
    </section>
 </div>
 
 


<script>
function sidebars(){
	var menu=document.getElementById("menu");
	menu.classList.toggle("active");
	
}
</script>
  <script type="text/javascript">
    $(document).ready(function(){
      //jquery for toggle sub menus
      $('.sub-btn').click(function(){
        $(this).next('.sub-menu').slideToggle();
        $(this).find('.dropdown').toggleClass('rotate');
      });
    });
	$(document).ready(function() {
    $('#example').DataTable();
} );
    </script>
	
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
	
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
	<script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>
