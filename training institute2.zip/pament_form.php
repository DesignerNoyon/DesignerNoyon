
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
<style type="text/css"> 
  	    form{
  			width:400px;
  			height:auto;
  			box-shadow:0 0 5px 1px;
  			padding:20px;
  			margin:5% auto;
  			box-sizing:border-box;
  		}
  		input{
  			width:100%;
  			height:32px;
  			margin:10px 0;	
  			padding-left:10px;
  			box-sizing:border-box;
  		}
    @media only screen and (max-width: 600px){
  	  	form{
  			width:90%;
  			display:block;
  		}	
    }
	
	 nav ul{
  	     display:flex;
  	     width:100%;
  	     background:none;
  	     height:50px;
  	     margin-left:-30px;
  	     border-bottom:1px solid #c3cace;
    }
  nav ul li{
       list-style:none;
       line-height:50px;
       margin-left:30px;
  }
  nav ul li a{
  	   text-decoration:none;
  	    color:black;
  }
  
</style>
</head>
<body>
	<br />
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
			 <li><a href="http://localhost/project/Website_project_demo/index.php?page=payment_voucher"><i class="fa fa-laptop"></i> জমার ভাউচার   </a></li>
    	    <li><a href="#"  style="color:black;"><i class="fa fa-laptop"></i>  নতুন জমা যুক্ত </a></li>
        </ul>
	</nav>
   <?php 
       include "connect.php";
	   if(isset($_POST['result'])){
		   $name=$_POST['name'];
		   $class=$_POST['class'];
		   $roll=$_POST['roll'];
		   $taka=$_POST['taka'];
		   $income_source=$_POST['income_source'];
		   $payment_date=$_POST['payment_date'];
		   $insert="INSERT INTO student_payment(name,class,roll,taka,income_source,payment_date)VALUES('$name','$class','$roll','$taka','$income_source','$payment_date')";
		   $query=mysqli_query($connect,$insert);

		
	   }
   
   ?>

	<form action="" method="POST"> 
	    <label for="">Name</label><br />
		  <input type="text" name="name" required /><br />
	    <label for="">Class</label><br />
		  <input type="text" name="class" required /><br />
	    <label for="">Roll</label><br />
		  <input type="text" name="roll" required /><br />
	    <label for="">Taka</label><br />
		  <input type="text" name="taka" required /><br />
		 <label for="">Income Source</label><br />
		  <input type="text" name="income_source" required /><br />
	    <label for="">Payment_date</label><br />
		  <input type="date" name="payment_date" required /><br />
		  <input type="submit" value="Result" name="result" />


	</form>
	
	
	
	<br /> <br />
</body>
</html>