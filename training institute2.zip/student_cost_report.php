<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
<style type="text/css"> 
    .onheader ul{
    	display:flex;
    	width:100%;
    	background:none;
    	height:50px;
    	margin-left:-30px;
    	border-bottom:1px solid #c3cace;
    }
    .onheader ul li{
       list-style:none;
       line-height:50px;
       margin-left:30px;
    }
    .onheader ul li a{
    	text-decoration:none;
    	color:black;  
    }
	form{
		width:400px;
		padding:10px;
		box-sizing:border-box;
	}
	lable{
		
	}
	 input{
		width:100%;
		padding-left:10px;
		box-sizing:border-box;
		margin:8px 0;
	}
	input[type="submit"]{
		background:#05566E;
		border:none;
		width:120px;
		color:#fff;
		border-radius:4px;
	}
	/* bootstrap data tables table customaize */
              .all-student{
              	width:100%;
              	overflow-x:scroll;
              	padding:20px;
              }
              table{
              	min-width:800px;
              	
              }
              table thead:nth-child(1){
              	background:#05566E;
              	max-height:40px !important;
              	color:#fff;
              	text-align:center;
              	
              	font-weight:bold;
              	
              }
              table tbody{
              	text-align:center;
              	line-height:60px;
              
              	
              }
              img{
              	width:80px;
              	height:60px;
              	object-fit:cover;
              }
              td .seemore{
              background:#05566E;
              width:120px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:20px;
              	line-height:40px;
              }
              td .seemore:hover{
              	background:#056480;
              }
			  tr td{
				  font-weight:bold;
			  }
			
		 td .delete{
              background:red;
              width:100px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:20px;
              	line-height:40px;
              }
              td .delete:hover{
              	background:#f00c0c;
              }

</style>
</head>
<body>
<br />
<div class="onheader"> 
    <ul>
    	<li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard" style="color:#007BFF;" ><i class="fas fa-home" aria-hidden="true"></i>  ড্যাশবোর্ড </a></li>
    	<li><a href="#" style="color:black;"><i class="fa fa-laptop" ></i>  ছাত্র/ছাত্রী খরচের রিপোর্ট  </a></li>
    </ul>
</div>
<div class="report"> 

 <form action="" method="POST">
  <label for="">শুরুর তারিখঃ </label>
  <input type="date" name="start_date" required />
  <label for="">শেষ তারিখঃ </label>
  <input type="date" name="end_date" required />
<input type="submit" value="Reporting" name="submit"/>

</div>
	
	<div class="all-student">
<table id="example" class="table table-striped">
        <thead>
			<tr>
				<td>Name</td>
				<td>Class</td>
				<td>Roll</td>
				<td>Taka</td>
				<td>Expense_source</td>
				<td>Expense_date</td>
				<td>Delete</td>
			</tr>
        </thead>
        <tbody>
<?php
     include "connect.php";
	  if(isset($_POST['submit'])){
       $start_date=$_POST['start_date'];
       $end_date=$_POST['end_date'];
       $expense_select="SELECT * FROM expense WHERE expense_date BETWEEN '$start_date' AND '$end_date'";
       $expense_query=mysqli_query($connect,$expense_select);
       while($expense_data=mysqli_fetch_assoc($expense_query)){
		   $id=$expense_data['id'];
		   $name=$expense_data['name'];
		   $class=$expense_data['class'];
		   $roll=$expense_data['roll'];
		   $taka=$expense_data['taka'];
		   $expense_source=$expense_data['expense_source'];
		   $expense_date=$expense_data['expense_date'];	 	 	 	
						echo "<tr> 
							    <td>$name</td>							    
						         <td>$class</td>
								 <td>$roll</td>
								 <td>$taka</td>
								 <td>$expense_source</td>
								 <td>$expense_date</td>
					<td><a href='delete.php?id=$id' class='delete'>Delete</a></td>
						   </tr>
						";
	   }}

?>

        </tbody>
    
    </table>
	</div>
	
	
	<br />
	<br />
	<br />
	
	
	
</body>
</html>