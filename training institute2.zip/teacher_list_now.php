
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="media.css" />
	<link rel="stylesheet" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="media.css" media="all" />
	<style type="text/css">
	
		.see_more{
			display:block;
			width:100%;
			margin:0 auto;
			align-items:center;
			margin-top:20px;
		}
		.see_more table{
			width:80%;
			
		}
		.see_more table tr{
			height:30px;
		}
		.see_more table tr td{
			padding-left:20px;
		}
		.see_more .profile h3{
			text-align:center;
			margin-top:-7px;
			color:#666;
			opacity:.5;
		}
		.see_more img{
			width:300px;
			height:150px;
			object-fit:cover;
		}
		
	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=list_teacher"  style="color:black;"><i class="fa fa-laptop"></i>  শিক্ষক তালিকা </a></li>
        </ul>
	</nav>
</div>
<center>
<div class="see_more">

	<?php 
		include "connect.php";
		$id=$_GET['id'];
		$select="SELECT * FROM add_teachers WHERE id='$id'";
		$query=mysqli_query($connect,$select);
		$data=mysqli_fetch_assoc($query);
						$id=$data['id'];
                        $joing_date=$data['joing_date'];
		                $dob=$data['dob'];
		                $name=$data['name'];
		                $father=$data['father'];
		                $mother=$data['mother'];
		                $phone=$data['phone'];
		                $email=$data['email'];
						$address=$data['address'];
		                $gender=$data['gender'];
		                $department=$data['department'];
		                $qualification=$data['qualification'];
		                $photo=$data['photo'];
		             
						echo "
						<div class='photo'>
						<img src='img/$photo'><br />
						</div>
						<table border='1' cellspacing='0'>
						
						<tr> 
							<td>Your name</td>
							<td>$name</td>
						</tr>
						<tr> 
							<td>Date Of Joining</td>
							<td>$dob</td>
						</tr>
						<tr> 
							<td>Your name</td>
							<td>$name</td>
						</tr>
						<tr> 
							<td>Father name</td>
							<td>$father</td>
						</tr>
						<tr> 
							<td>Mother name</td>
							<td>$mother</td>
						</tr>
						<tr> 
							<td>Phone</td>
							<td>$phone</td>
						</tr>
						<tr> 
							<td>Email</td>
							<td style='color:green;'>$email</td>
						</tr>
						<tr> 
							<td>Address</td>
							<td>$address</td>
						</tr>
						<tr> 
							<td>Gender</td>
							<td>$gender</td>
						</tr>
						<tr> 
							<td>Department</td>
							<td>$department</td>
						</tr>
						<tr> 
							<td>Qualification</td>
							<td>$qualification</td>
						</tr>
						<tr> 
							<td>Photo</td>
							<td>$photo</td>
						</tr>
						</table>
						
						";
						
		
	?>
</div>
	 </center>
	 <br /> <br />
	 <script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>