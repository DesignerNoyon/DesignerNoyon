<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
<style type="text/css"> 
  	    form{
  			width:400px;
  			height:auto;
  			box-shadow:0 0 5px 1px green;
  			padding:20px;
  			margin:5% auto;
  			box-sizing:border-box;
  		}
  		input{
  			width:100%;
  			height:32px;
  			margin:10px 0;	
  			padding-left:10px;
  			box-sizing:border-box;
  		}
    @media only screen and (max-width: 600px){
  	  	form{
  			width:90%;
  			display:block;
			margin-top:50px;
  		}	
	  .btn_div li{
		 float:right;
		 margin-top:50px;
		 margin-right:30px;
	 }
    }
	  .btn_div{
		 float:right;
		 margin-top:-30px;
		 margin-right:20px;
	 }
     .btn_div li{
		 width:100px;
		 list-style:none;
		 
	 }
	 .btn_div li a{
		 color:black;
		 font-size:17px;
		 font-weight:bold;
		 transition:.6s;
		 text-decoration:noen;
	 }
	.btn_div li a:hover{
		color:red;
	}
  
</style>
	
</head>
<body>
   
   <?php 
       include "connect.php";
	   if(isset($_POST['result'])){
		     $name=$_POST['name'];
		     $username=$_POST['username'];
		     $email=$_POST['email'];
		     $password=$_POST['password'];
			$insert="INSERT INTO register_form(name,username,email,password)VALUES('$name','$username','$email','$password')";
			$query=mysqli_query($connect,$insert);
	   }
   
   ?>
	  <div class="btn_div"> 
	      <li><a href="http://localhost/project/Website_project_demo/login_form.php">Login from</a></li>
	</div>
	<form action="" method="POST"> 
	    <label for="">Name</label>
		   <input type="text" name="name" required />
	    <label for="">Username</label>
		   <input type="text" name="username" required />
	    <label for="">Email</label>
		   <input type="email" name="email" required />
	    <label for="">Password</label>
		   <input type="password" name="password" required />
      <input type="submit" value="submit" name="result" />
	
	</form>
	
	
	
	
	
	
	<br /> <br />
	
</body>
</html>