<?php 
     include "connect.php";
	 $id=$_GET['id'];
	 $delete="DELETE FROM stuednt_dutb WHERE id='$id'";
	 $query=mysqli_query($connect,$delete);
	 header("location:http://localhost/project/Website_project_demo/index.php?page=student_list");

?>