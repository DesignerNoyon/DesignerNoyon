
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
<style type="text/css"> 
  	    form{
  			width:85%;
  			height:auto;
  			box-shadow:0 0 5px 1px;
  			padding:20px;
  			margin:5% auto;
  			box-sizing:border-box;
  			display:flex;
  		}
  		.form{
  			margin:0 5px;
  		}
  		input{
  			width:100%;
  			height:32px;
  			margin:10px 0;	
  			padding-left:10px;
  			box-sizing:border-box;
  		}
		 select{
			 width:100%;
  			height:32px;
		 }
		textarea{
			width:100%;
  			height:90px;
		}
		
  			h1{
  				text-align:center;
  			}
  	.onheader ul{
  	     display:flex;
  	     width:100%;
  	     background:none;
  	     height:50px;
  	     margin-left:-30px;
  	     border-bottom:1px solid #c3cace;
    }
  .onheader ul li{
       list-style:none;
       line-height:50px;
       margin-left:30px;
  }
  .onheader ul li a{
  	   text-decoration:none;
  	    color:black;
  }
  .headierk {
  	  width:100%;
  	  height:50px;
  	  background:black;
  }
  .headierk p{
  	  color:#fff;
  	  line-height:45px;
  	  font-size:14px;
  	  text-align:center;
  }		
    @media only screen and (max-width: 600px){
  	  	form{
  			width:90%;
  			display:block;
  		}
  		.headierk p{
  	         color:black;
  	         line-height:45px;
  	         font-size:12px;
  	         text-align:center;
        }	
    }
  
</style>
</head>
<body>
<div class="onheader"> 
    <ul>
    	<li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true" style="color:#007BFF;"></i>  ড্যাশবোর্ড </a></li>
    	<li><a href="#"><i class="fa fa-laptop" ></i>  শিক্ষক তৈরি  </a></li>
    </ul>
</div>

   <?php 
       include "connect.php";
	   if(isset($_POST['result'])){
		   $joing_date=$_POST['joing_date'];
		   $dob=$_POST['dob'];
		   $name=$_POST['name'];
		   $father=$_POST['father'];
		   $mother=$_POST['mother'];
		   $phone=$_POST['phone'];
		   $email=$_POST['email'];
		   $address=$_POST['address'];
		   $gender=$_POST['gender'];
		   $department=$_POST['department'];
		   $qualification=$_POST['qualification'];
		   $photo=$_FILES['photo']['name'];
		   $tmp=$_FILES['photo']['tmp_name'];
		   move_uploaded_file($tmp,'img/'.$photo);
		   $insert="INSERT INTO add_teachers(joing_date,dob,name,father,mother,phone,email,address,gender,department,qualification,photo)VALUES('$joing_date','$dob','$name','$father','$mother','$phone','$email','$address','$gender','$department','$qualification','$photo')";
		   $query=mysqli_query($connect,$insert);

		
	   }
   
   ?>


	<form action="" method="POST" enctype= "multipart/form-data">
	    <div class="form"> 
		       <label for="">Date Of Birth *</label>
	    	     <input type="date" name="joing_date" required />
              <label for="">Name *</label>
	    	     <input type="text" name="name" required />
	        <label for="">Father*</label>
	    	     <input type="text" name="father" required />
              <label for="">Department *</label>
	    	       <select name="department" id="" required>
	    		   <option value="select">Select</option>
	    		   <option value="english">English</option>
	    		   <option value="bangla">Bangla</option>
	    		   <option value="general science">General Science</option>
	    		   <option value="mathmatics">Mathmatics</option>
	    		   <option value="religion">Religion</option>
	    		  </select>						  
              <label for="">Phone *</label>
	    	     <input type="text" name="phone" required />
				 			  
	    		<label for="">Photo</label>
	    		<input type="file" name="photo" id="" required />
           <input type="submit" value="Submit" name="result" />					 
		</div>    
		 <div class="form">  
              <label for="">Date Of Joining *</label>
	    	     <input type="date" name="dob" required />	
	        <label for="">Email *</label>
	    	     <input type="email" name="email" required />
              <label for="">Mother</label>
	    	     <input type="mother" name="mother" required />	
               <label for="">Gender *</label>
	    	      <select name="gender" id="" required>
				   <option value="select">Select</option>
	    		   <option value="Male">Male</option>
	    		   <option value="female">Female</option>
	    		  </select>						 
              <label for="">Address</label>
	    	     <input type="text" name="address" required />	

              <label for="">Qualification</label>
	               <textarea name="qualification" id="" cols="30" rows="10" required></textarea>		    		
	     </div>		 
	</form>
	<br /> <br />
    <div class="headierk"> 
        <p><span style="color:green;">Student management system /</span> কপিরাইট © 2018- <span style="color:red;">2022 Soft Host IT /</span>. সর্বস্বত্ব সংরক্ষিত!. গোপনীয়তা এবং শর্তাদি</p>
	</div>
	<br /> <br />
</body>
</html>