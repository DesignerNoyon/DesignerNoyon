          <?php
				include "connect.php";
				$id=$_GET['id'];
					$select="SELECT * FROM expense WHERE id='$id'";
					$query=mysqli_query($connect,$select);
					$data=mysqli_fetch_assoc($query);
						$id=$data['id'];
						$expense_source=$data['expense_source'];
		                $name=$data['name'];
		                $class=$data['class'];
		                $roll=$data['roll'];
		                $taka=$data['taka'];
		                $expense_date=$data['expense_date'];
					
				?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	.voucher{
		width:576px;
		height:350px;
		box-shadow:0 0 5px 1px #035373;
		border-top-left-radius:10px;
		margin:5% auto;
		padding:10px;
		box-sizing:border-box;
	}
	.voucher h1{
		font-size:20px;
		text-align:center;
		color:#056480;
		padding-top:10px;
		word-spacing:2px;
	}
	.voucher p{
		text-align:center;
		margin-top:-10px;
	}
	.main_div{
		display:flex;
		justify-content:space-between;
	
	}
	.value{
		margin-left:7px;
		border-bottom:1px dotted black;
		padding:0 14px;
	}
	.second_div{
		display:flex;
		margin-top:10px;
		
	}
	.second_div .student_info{
		margin-right:20px;
	}
	table{
		width:90%;
		
		margin:5% auto;
	}
	table tr td{
		padding:0 10px;
	}
	
	.reiad{
		margin-left:7px;
		border-bottom:1px dotted black;
		padding:0 14px;
	}
	.pra{
	     color:black;
	    float:right;
		margin-right:30px;
	}
	 .onserve nav ul{
  	     display:flex;
  	     width:95%;
  	     background:none;
  	     height:50px;
  	     border-bottom:1px solid #c3cace;
    }
  .onserve nav ul li{
       list-style:none;
       line-height:50px;
       margin-left:30px;
  }
  .onserve nav ul li a{
  	   text-decoration:none;
  	    color:black;
  }
	
	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=expense_vouchers"  style="color:#3272B8;"><i class="fa fa-laptop"></i>  খরচের ভাউচার   </a></li>

        </ul>
	</nav>
</div>

	<div class="voucher"> 
	  <h1>ফিউচার কম্পিউটার ট্রেনিং ইনস্টিউচ,মাদারিপুর</h1>
	  <p>পুরান বাস-স্টান্ড,মাদারিপুর</p>
	  <p style="font-size:14px;">বেতন আদায়ের রশিদ</p>
	  <div class="main_div">
	  <div class="student_info"> 
	     <label for="">ছাত্র/ছাত্রীর নাম : </label>
	     <label for="" class="value"> <?=$name;?></label>
	  </div>
    <div class="student_info"> 
	     <label for="">তারিখ : </label>
	     <label for="" class="value"> <?=$expense_date;?></label>
	  </div>
    </div>
	
	
	
<div class="second_div">
	  <div class="student_info"> 

	  </div>
    <div class="student_info"> 
	     <label for="">রোল নং : </label>
	     <label for="" class="value"> <?=$roll;?></label>
	  </div>
    </div>
	
	<table border="1" cellspacing="0">
	    <tr>
	    	<td>আদায়ের বিবরন</td>
	    	<td>টাকা</td>
	    </tr>
	    
        <tr>
	    	<td> 1 |  <?=$expense_source;?></td>
	    	<td><?=$taka?></td>
	    </tr>
	</table>
	<div class="pra"> 
		     <label for="">আদায়কারীর স্বক্ষক  : </label>
	   
	</div>
</div>

	
	<br /> <br /> <br />
	
<script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>