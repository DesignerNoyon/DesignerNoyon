
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	/* bootstrap data tables table customaize */
              .all-student{
              	width:100%;
              	overflow-x:scroll;
              	padding:20px;
              }
              table{
              	min-width:800px;
              	
              }
              table thead:nth-child(1){
              	background:black;
              	max-height:40px !important;
              	color:#fff;
              	text-align:center;
              	
              	font-weight:bold;
              	
              }
              table tbody{
              	text-align:center;
              	line-height:60px;
              
              	
              }
			  tr td{
				  font-weight:bold;
				  font-size:15px;
			  }
              img{
              	width:80px;
              	height:60px;
              	object-fit:cover;
              }
              td .seemore{
              background:black;
              width:90px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:17px;
              	line-height:40px;
				transition:.5s;
              }
              td .seemore:hover{
              	background:#2e2424;
              }
			
		 td .delete{
              background:red;
              width:80px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:17px;
              	line-height:40px;
				transition:.5s;
              }
              td .delete:hover{
              	background:#8d0d0d;
              }

	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="#"  style="color:black;"><i class="fa fa-laptop"></i>  শিক্ষক তালিকা  </a></li>
        </ul>
	</nav>
</div>
<div class="all-student">
<table id="example" class="table table-striped">
        <thead>
			<tr>
			    <td>id</td>
				<td>Student Name</td>
				<td>Photo</td>
				<td>See more</td>
				<td>Delete</td>
			</tr>
        </thead>
        <tbody>
		
				<?php
					include "connect.php";
					$select="SELECT * FROM add_teachers";
					$query=mysqli_query($connect,$select);
					while($data=mysqli_fetch_assoc($query)){
						$id=$data['id'];
		                $joing_date=$data['joing_date'];
		                $dob=$data['dob'];
		                $name=$data['name'];
		                $father=$data['father'];
		                $mother=$data['mother'];
		                $phone=$data['phone'];
		                $email=$data['email'];
		                $address=$data['address'];
		                $gender=$data['gender'];
		                $department=$data['department'];
		                $qualification=$data['qualification'];
						$photo=$data['photo'];
						echo "<tr> 
							    <td style='color:#2a1616; font-size:20px;'>$id</td>							    
						         <td style='color:#2a1616; font-size:20px;'>$name</td>
							    <td><img src='img/$photo' /></td>
							    <td><a href='teacher_list_now.php?id=$id' class='seemore'><i class='fa fa-eye'></i> more</a></td>
								<td><a href='delete.php?id=$id' class='delete'>Delete</a></td>
						   </tr>
						";
					}
				?>
        </tbody>
    
    </table>
	</div>
	<br />
	<br />
	<br />
	<br />
		
</body>
</html>