
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	/* bootstrap data tables table customaize */
              .all-student{
              	width:100%;
              	overflow-x:scroll;
              	padding:20px;
              }
              table{
              	min-width:1000px;
              	
              }
              table thead:nth-child(1){
              	background:#2c8f6f;
              	max-height:40px !important;
              	color:#fff;
              	text-align:center;
              	
              	font-weight:bold;
              	
              }
              table tbody{
              	text-align:center;
              	line-height:60px;
              
              	
              }
			  tr td{
				  font-weight:bold;
				  font-size:15px;
			  }
              img{
              	width:80px;
              	height:60px;
              	object-fit:cover;
              }
              td .seemore{
              background:#003826;
              width:90px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:17px;
              	line-height:40px;
				transition:.5s;
              }
              td .seemore:hover{
              	background:#2e2424;
              }
			
		 td .delete{
              background:red;
              width:80px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:17px;
              	line-height:40px;
				transition:.5s;
              }
              td .delete:hover{
              	background:#8d0d0d;
              }
			  .btn_div{
				  position:absolute;
	               right:40px;
				   margin-top:30px;
			  }
			  .btn_div li{
				  width:100px;
				  height:35px;
				  background:red;
				  text-align:center;
				  list-style:none;
				  cursor:pointer;
				  transition:.5s;
			  }
			  .btn_div li:hover{
				  background:black;
			  }
			  .btn_div li a{
				   color:#fff;
				  text-decoration:none;
				  line-height:32px;
			  }
			  .headierk {
	              width:100%;
	              height:50px;
	              background:#E3F2FD;
              }
             .headierk p{
             	color:black;
             	line-height:45px;
             	font-size:14px;
             	text-align:center;
             }		
               @media only screen and (max-width: 600px){
             		.headierk p{
             	        color:black;
             	        line-height:45px;
             	         font-size:12px;
             	         text-align:center;
                }	
  }

	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="#"  style="color:black;"><i class="fa fa-laptop"></i> খরচের ভাউচার  </a></li>

        </ul>
	</nav>
</div>
<div class="all-student">
<table id="example" class="table table-striped">
        <thead>
			<tr>
				<td>Name</td>
				<td>Class</td>
				<td>Roll</td>
				<td>Taka</td>
				<td>Expense_date</td>
				<td>See more</td>
				<td>Delete</td>
			</tr>
        </thead> 
        <tbody>
			<?php
				include "connect.php";
					$select="SELECT * FROM expense";
					$query=mysqli_query($connect,$select);
					while($data=mysqli_fetch_assoc($query)){
						$id=$data['id'];
		                $name=$data['name'];
		                $class=$data['class'];
		                $roll=$data['roll'];
		                $taka=$data['taka'];
		                $expense_date=$data['expense_date'];
						echo "<tr> 					    
						     <td style='color:#161212; font-size:17px;'>$name</td>
						    <td style='color:#161212; font-size:17px;'>$class</td>
						     <td style='color:#161212; font-size:17px;'>$roll</td>
						     <td style='color:#161212; font-size:17px;'>$taka</td>
					<td style='color:#161212;; font-size:17px;'>$expense_date</td>
					
				    <td><a href='expense_print.php?id=$id' class='seemore'><i class='fa fa-print'></i> Print</a></td>
					
				    <td><a href='expense_delete.php?id=$id' class='delete'>Delete</a></td>
						   </tr>
						";
					}
				?>

        </tbody>
    
    </table>
	</div>
	<div class="btn_div"> 
	     <li><a href="http://localhost/project/Website_project_demo/index.php?page=expense_form"><i class="fa fa-plus-square"></i> নতুন খরচ</a></li>
	</div>
	
	
	
		<br /> <br /><br /> <br /> <br />
	<div class="headierk"> 
        <p><span style="color:#4463DC;">Student management system /</span> কপিরাইট © 2018- <span style="color:#4463DC;">2022 Soft Host IT /</span>. সর্বস্বত্ব সংরক্ষিত!. গোপনীয়তা এবং শর্তাদি</p>
	</div>
	 <br /> <br />
	
	
		<script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>
