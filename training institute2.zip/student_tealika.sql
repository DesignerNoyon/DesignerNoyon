-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2022 at 07:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_tealika`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_teacher`
--

CREATE TABLE `add_teacher` (
  `father` varchar(200) NOT NULL,
  `mother` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `department` varchar(200) NOT NULL,
  `qualification` varchar(1000) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_teacher`
--

INSERT INTO `add_teacher` (`father`, `mother`, `phone`, `email`, `address`, `gender`, `department`, `qualification`, `photo`) VALUES
('Fazlur Rahman', 'Kohinur Begum', '', 'noyon93@gmail.com', 'Kulpuddi,Madaripur', 'female', 'english', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', ''),
('', '', '', '', '', 'select', 'select', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `add_teachers`
--

CREATE TABLE `add_teachers` (
  `id` int(11) NOT NULL,
  `joing_date` date NOT NULL,
  `dob` date NOT NULL,
  `name` varchar(200) NOT NULL,
  `father` varchar(200) NOT NULL,
  `mother` varchar(200) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `qualification` varchar(2000) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_teachers`
--

INSERT INTO `add_teachers` (`id`, `joing_date`, `dob`, `name`, `father`, `mother`, `phone`, `email`, `address`, `gender`, `department`, `qualification`, `photo`) VALUES
(3, '2022-04-01', '2022-04-08', 'shoun', 'Solaman Sarder', 'Kohinur Begum', '01307074694', 'shoun@gmail.com', 'Madaripur,Kulpuddi', 'female', 'mathmatics', 'I have a three years experence for my work', '7march.jpg'),
(4, '2022-04-27', '2022-04-11', 'Ashikur Rahman', 'Fazlur Rahman', 'Kohinur Begum', '01521', 'eysen@gmail.com', 'Fire Service Madaripur', 'Male', 'bangla', 'hellow my name is shu', 'IMG_20210802_175129.jpg'),
(5, '2022-04-20', '2022-04-28', 'noyon', 'nayem Sarder', 'Monia Begum', '2385468452', 'noyon93@gmail.com', 'Kulpuddi,Madaripur', 'Male', 'bangla', 'Kulpuddi,Madaripur Kulpuddi,Madaripur', 'IMG_20210802_182906.jpg'),
(6, '2022-04-07', '2022-04-13', 'noyon', 'nayem Sarder', 'Kohinur Begum', '2385468452', 'coder95@gmail.com', 'Kulpuddi,Madaripur', 'select', 'bangla', ' my name is lshoun', 'bodyimg3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `roll` varchar(100) NOT NULL,
  `taka` varchar(100) NOT NULL,
  `expense_source` varchar(100) NOT NULL,
  `expense_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `name`, `class`, `roll`, `taka`, `expense_source`, `expense_date`) VALUES
(2, 'noyon', '07', '02', '1000', 'food', '2022-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `register_form`
--

CREATE TABLE `register_form` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register_form`
--

INSERT INTO `register_form` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'shoun', 'ahmedshoun', 'noyon93@gmail.com', '12345687'),
(2, 'shoun', 'ahmedshoun', 'noyon93@gmail.com', '12345687'),
(3, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(4, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(5, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(6, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(7, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(8, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(9, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687'),
(10, 'Freelancer Noyon', 'ahmedshoun93@gmail.com', 'shoun@gmail.com', '12345687');

-- --------------------------------------------------------

--
-- Table structure for table `student_payment`
--

CREATE TABLE `student_payment` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `roll` varchar(100) NOT NULL,
  `taka` varchar(100) NOT NULL,
  `income_source` varchar(200) NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_payment`
--

INSERT INTO `student_payment` (`id`, `name`, `class`, `roll`, `taka`, `income_source`, `payment_date`) VALUES
(11, 'shoun', '07', '4405100', '2000', 'admission', '2022-04-04'),
(13, 'noyon', '1', '4405101', '16000', 'admission', '2022-04-10'),
(14, 'Freelancer Noyon', '07', '03', '20000', 'admission', '2022-04-12'),
(15, 'shoun', '1', '1', '1000', 'admission', '2022-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `stuednt_dutb`
--

CREATE TABLE `stuednt_dutb` (
  `id` int(11) NOT NULL,
  `add_date` date NOT NULL,
  `birth_date` date NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `profile` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `roll` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `parents_phone` varchar(100) NOT NULL,
  `course_fee` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stuednt_dutb`
--

INSERT INTO `stuednt_dutb` (`id`, `add_date`, `birth_date`, `name`, `username`, `profile`, `email`, `roll`, `mother_name`, `father_name`, `class`, `phone`, `parents_phone`, `course_fee`, `district`, `thana`) VALUES
(205, '2022-04-11', '2022-04-13', 'noyon', 'shun sarder', 'IMG_20210802_183110.jpg', 'coder95@gmail.com', '321', 'dkjhuhyt', 'nayem Sarder', '23', '2385468452', '215236454', '3000', 'jhujgyh', 'Madaripur sadar'),
(209, '2022-04-01', '2022-04-26', 'noyon', 'adminzahid', '23.jpg', 'ahmedshoun93@gmail.com', '4405100', 'salma bagom', 'Solaman Sarder', '07', '01307074694', '01609040260', '20000', 'Madaripur', 'Madaripur sadar'),
(210, '2022-04-04', '2022-04-05', 'Eysen', 'adminzahid', 'banner3.jpg', 'eysen@gmail.com', '05', 'salma bagom', 'Fazlur Rahman', '01', '2385468452', '215236454', '3000', 'jhujgyh', 'Madaripur sadar'),
(211, '2022-04-19', '2022-04-20', 'nayem', 'adminzahid', 'unnamed.png', 'nayem@gmail.com', '36', 'Kohinur Begum', 'Munna Hasan', '10', '015607598', '45989898', '3200', 'Madaripur', 'Madaripur '),
(212, '2022-04-22', '2022-04-29', 'Eysen Ahmed', 'mdshoun', 'bodyimg3.jpg', 'coder95@gmail.com', '11', 'Kohinur Begum', 'nayem Sarder', '09', '015607598', '5645875', '5000', 'Madaripur', 'Madaripur'),
(214, '2022-04-12', '2022-04-13', 'Shoun naem', 'adminzahid', 'IMG_20210802_183036.jpg', 'coder95@gmail.com', '06', 'Monia Begum', 'Fazlur Rahman', '56', '05', '215236454', '30000', 'Madaripur', 'Madaripur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_teachers`
--
ALTER TABLE `add_teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_form`
--
ALTER TABLE `register_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_payment`
--
ALTER TABLE `student_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stuednt_dutb`
--
ALTER TABLE `stuednt_dutb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_teachers`
--
ALTER TABLE `add_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `register_form`
--
ALTER TABLE `register_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_payment`
--
ALTER TABLE `student_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `stuednt_dutb`
--
ALTER TABLE `stuednt_dutb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
