
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="media.css" />
	<link rel="stylesheet" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="media.css" media="all" />
	<style type="text/css">
	
		.see_more{
			display:flex;
			width:100%;
			justify-content:center;
			align-items:center;
			margin-top:80px;
		}
		.see_more table{
			width:400px;
		}
		.see_more table tr td{
			padding-left:7px;
		}
		.see_more .profile h3{
			text-align:center;
			margin-top:-7px;
			color:#666;
			opacity:.5;
		}
		.see_more img{
			width:250px;
			height:200px;
			object-fit:cover;
			margin:5px 50px;
		}
		
	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=student_list"  style="color:#007BFF;"><i class="fa fa-laptop"></i>  ছাত্র/ছাত্রী লিস্ট  </a></li>
        </ul>
	</nav>
</div>
<div class="see_more">

	<?php 
		include "connect.php";
		$id=$_GET['id'];
		$select="SELECT * FROM stuednt_dutb WHERE id='$id'";
		$query=mysqli_query($connect,$select);
		$data=mysqli_fetch_assoc($query);
						$id=$data['id'];
                        $add_date=$data['add_date'];
		                $birth_date=$data['birth_date'];
		                $name=$data['name'];
		                $username=$data['username'];
		                $profile=$data['profile'];
		                $email=$data['email'];
		                $roll=$data['roll'];
						$mother_name=$data['mother_name'];
		                $father_name=$data['father_name'];
		                
		                $phone=$data['phone'];
		                $parents_phone=$data['parents_phone'];
		                $classs=$data['class'];
		                $district=$data['district'];
		                $thana=$data['thana'];
						echo "
						<div class='profile'>
						<img src='img/$profile'><br />
						<h3>$name</h3>
						</div>
						<table border='1' cellspacing='0'>
						
						<tr> 
							<td>Add_date</td>
							<td>$add_date</td>
						</tr>
						<tr> 
							<td>Birth_date</td>
							<td>$birth_date</td>
						</tr>
						<tr> 
							<td>Your name</td>
							<td>$name</td>
						</tr>
						<tr> 
							<td>Username</td>
							<td>$username</td>
						</tr>
						<tr> 
							<td>Email</td>
							<td>$email</td>
						</tr>
						<tr> 
							<td>Roll</td>
							<td>$roll</td>
						</tr>
						<tr> 
							<td>Mother_name</td>
							<td style='color:green;font-size:20px;'>$mother_name</td>
						</tr>
						<tr> 
							<td>Father_name</td>
							<td style='color:red;font-size:20px;'>$father_name</td>
						</tr>
						<tr> 
							<td>Phone</td>
							<td>$phone</td>
						</tr>
						<tr> 
							<td>Parents_phone</td>
							<td>$parents_phone</td>
						</tr>
						<tr> 
							<td>Class</td>
							<td>$classs</td>
						</tr>
						<tr> 
							<td>District</td>
							<td>$district</td>
						</tr>
						<tr> 
							<td>Thana</td>
							<td>$thana</td>
						</tr>
						</table>
						
						";
						
		
	?>
	 </div>
	 
	 <br /> <br /> <br /> <br />
	 <script src="https://kit.fontawesome.com/4054c17799.js"></script>
</body>
</html>