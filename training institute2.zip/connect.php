<?php 
    $connect=mysqli_connect("localhost","root","","student_tealika");
?>