
<?php
include "connect.php";
$all_student_query=mysqli_query($connect,"SELECT count(id) as total_student FROM stuednt_dutb");
$all_student_data=mysqli_fetch_assoc($all_student_query);
$all_student=$all_student_data['total_student'];
$all_students=str_pad($all_student, 2, '0', STR_PAD_LEFT);
// teacher list


$all_teacher_query=mysqli_query($connect,"SELECT count(id) as total_teachers FROM add_teachers");
$all_teacher_data=mysqli_fetch_assoc($all_teacher_query);
$all_teacher=$all_teacher_data['total_teachers'];
$all_teachers=str_pad($all_teacher, 2, '0', STR_PAD_LEFT);


// today income
$date=date('Y-m-d');
$today_income_query=mysqli_query($connect,"SELECT sum(taka) as today_income FROM student_payment WHERE payment_date='$date'");
$today_income_query_data=mysqli_fetch_assoc($today_income_query);
$all_today_income=$today_income_query_data['today_income'];


?>






<br />
<div class="onheader"> 
    <ul>
    	<li><a href="#"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i>  ড্যাশবোর্ড  </a></li>
    </ul>
</div>

<div class="container-fluid" style="margin-top:30px;">
   <div class="row" >
        <div class="col-md-3">
            <div class="panel-primary">
               <div class="panel-heading py-0" style="background:#007BFF;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="clearfix"></div>
                            <div class="pull-right" style="font-size:20px;">ছাত্র/ছাত্রী যুক্ত</div>    	
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=add_student">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        
		       <div class="col-md-3">
            <div class="panel-primary">
               <div class="panel-heading py-0" style="background:#28A745;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="clearfix"></div>
                            <div class="pull-right" style="font-size:20px;">ছাত্র/ছাত্রী লিষ্ট</div>    	
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=student_list">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
				       <div class="col-md-3">
            <div class="panel-primary">
               <div class="panel-heading py-0" style="background:#FF6600;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="clearfix"></div>
                            <div class="pull-right" style="font-size:20px;">শিক্ষক  যুক্তু</div>    	
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=add_teacher">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
		
	  <div class="col-md-3">
            <div class="panel-primary">
               <div class="panel-heading py-0" style="background:#4463DC;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="clearfix"></div>
                            <div class="pull-right" style="font-size:20px;">শিক্ষক লিষ্ট</div>    	
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=list_teacher">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>

       
        </div>
        


<br />
<br />


   <div class="row">
        <div class="col-md-4">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#9E00C1;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:30px;font-weight:bold;"><?=$all_students;?></div>
                            <div class="clearfix"></div>
                            <div class="pull-right">ছাত্র/ছাত্রী লিষ্ট</div>
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=student_list">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        
		
		        <div class="col-md-4">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#257874;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:30px;font-weight:bold;"><?=$all_teachers;?></div>
                            <div class="clearfix"></div>
                            <div class="pull-right">শিক্ষক লিষ্ট</div>
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=list_teacher">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">View Now</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
       	        <div class="col-md-4">
            <div class="panel-primary">
                <div class="panel-heading py-0" style="background:#DC3545;color:#fff;padding:10px 15px;border-top-left-radius:6px;border-top-right-radius:6px">
                    <div class="row">                    
                        <div class="col-xs-9"style="padding:10px 15px;">
						<div class="col-xs-3 pull-left"><i class="fa fa-users" style="font-size:45px;"></i></div>
                            <div class="pull-right" style="font-size:30px;font-weight:bold;"><?=$all_today_income;?></div>
                            <div class="clearfix"></div>
                            <div class="pull-right">আজকের আয়</div>
                        </div>
                    </div>
                </div>
                <a href="http://localhost/project/Website_project_demo/index.php?page=pament_form">
                    <div class="panel-footer"style="background:#ededed;padding:10px 15px;color:#337ab7;">
                        <span class="pull-left" style="font-size:15px;">Add income</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-o-right" style="font-size:24px;"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        </div>
	 <br /> <br />
	 <br /> <br />
 	<div class="headierk"> 
        <p><span style="color:#4463DC;">Student management system /</span> কপিরাইট © 2018- <span style="color:#4463DC;">2022 Soft Host IT /</span>. সর্বস্বত্ব সংরক্ষিত!. গোপনীয়তা এবং শর্তাদি</p>
	</div>

</div>



<script src="https://kit.fontawesome.com/4054c17799.js"></script>
<br />
<br />