
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	@import url('https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@200&display=swap');
	    .id_card{
			width:300px;
			height:240px;
			box-shadow:0 0 5px 1px;
			margin:10% auto;
			border-top-left-radius:25px;
			border-top-right-radius:25px;
			border-bottom-left-radius:25px;
			border-bottom-right-radius:25px;
		}
		.id_name{
			width:100%;
			height:50px;
			background:green;
			text-align:center;
			border-top-left-radius:25px;
			border-top-right-radius:25px;
		}
		.id_name h2{
			color:#fff;
			font-size:20px;
			line-height:50px;
			font-family: 'Source Serif Pro', serif;
		}
		.id_name p{
			color:#fff;
			font-size:15px;
			margin-top:-17px;
		}
		.id_card1 button{ 
		    width:140px;
			height:30px;
			background:green;
			color:#fff;
			border:none;
			font-size:16px;
			border-radius:10px;
		    margin-top:15px;
		}
		img{
			width:100px;
			height:90px;
			margin-top:50px;
		}
		.id_card_mandiv{
			display:flex;
			justify-content:space-around;
		}
		
		.of_line{
			width:100%;
			height:30px;
			background:green;
			margin-top:-5px;
			border-bottom-left-radius:25px;
			border-bottom-right-radius:25px;
		}
		.of_line p{
			color:#fff;
			font-size:17px;
			text-align:center;
			line-height:30px;
		}
     tr td{
		 margin-top:-50px;
	 }
	</style>
</head>
<body>
	<div class="id_card"> 
	    <div class="id_name"> 
		     <h2>Future computer training</h2>
		</div>
		<div class="id_card_mandiv"> 
		    <div class="id_card1"> 
			   <button>Student id card</button>
			<?php 
			    include "connect.php";
		        $id=$_GET['id'];
		        $select="SELECT * FROM stuednt_dutb WHERE id='$id'";
		        $query=mysqli_query($connect,$select);
		        $data=mysqli_fetch_assoc($query);
				$name=$data['name'];
				$father_name=$data['father_name'];
				$roll=$data['roll'];
				$phone=$data['phone'];
										echo "
						<table style='margin-top:-13px;'>
						<tr> 
							<h3 style='color:green; font-size:20px; margin-top:5px; margin-left:10px;'>$name</h3>
						</tr>
						<tr> 
							<td>Roll : </td>
							<td>$roll</td>
						</tr>
						<tr> 
							<td>Father : </td>
							<td>$father_name</td>
						</tr>
						<tr> 
							<td>Phone : </td>
							<td>$phone</td>
						</tr>
						</table>
						
						";
			
			?>
			
			
			   
			</div>
			
			<div class="id_card_img"> 
			    <?php 
				   	include "connect.php";
		            $id=$_GET['id'];
		            $select="SELECT * FROM stuednt_dutb WHERE id='$id'";
		            $query=mysqli_query($connect,$select);
		            $data=mysqli_fetch_assoc($query);
				    $profile=$data['profile'];
				   	echo "
						<div class='profile'>
						    <img src='img/$profile'><br />  
						</div>
						
						";
				?>
				
			</div>					
		
		</div>
		
		<div class="of_line"> 
		    <i><p>future computer training institute</p></i>
		</div>
		
	
	</div>
	
	
	
</body>
</html>