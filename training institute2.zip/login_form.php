<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	*{
		margin:0;
		padding:0;
	}
	    .form{
			width:100%;
			min-height:100vh;
			background-image:url(img/pngtree.jpg);
	        background-size:cover;
	        background-position:center;
	        background-repeat:no-repeat;
			object-fit:cover;
			position:fixed;
			
		}
  	    form{
  			width:300px;
  			height:auto;
  			background:#49AEFF;
  			padding:20px;
  			box-sizing:border-box;
			margin-left:50px;
			margin-top:15%;
			position:fixed;
			border-bottom-right-radius:30px;
  		}
  		input{
  			width:100%;
  			height:32px;
  			margin:10px 0;	
  			padding-left:10px;
  			box-sizing:border-box;
  		}
	    form input[type='submit']{
	          background:#244e73;
	      color:#fff;
	      font-size:18px;
      	font-weight:bold;
      	border:none;
		width:130px;
		height:32px;
      	margin-top:15px;
		cursor:pointer;
      	transition:.5s;
      }
	form input[type='submit']:hover{
		background:#385977;
	}
     .btn_div{
		 float:right;
		 margin-top:16px;
		 margin-right:50px;
	 }
     .btn_div li{
		 width:100px;
		 list-style:none;
		 
	 }
	 .btn_div li a{
		 color:#fff;
		 font-size:17px;
		 font-weight:bold;
		 transition:.6s;
		 text-decoration:noen;
	 }
	.btn_div li a:hover{
		color:#bbb3b3;
	}
</style>
	
</head>
<body>
<?php
session_start();
	include "connect.php";
	if(isset($_POST['username']) && isset($_POST['password'])){
		$username=$_POST['username'];
		$password=$_POST['password'];
		$select="SELECT * FROM register_form WHERE username='$username' AND password='$password'";
		$query=mysqli_query($connect,$select);
		$data=mysqli_fetch_assoc($query);
		if($data){
		$_SESSION['login_form']=$username;
			header("location:http://localhost/project/Website_project_demo/index.php?page=dashboard");
		}
		
		}
		
	
?>

       <div class="form"> 
	        <div class="btn_div"> 
			   <li><a href="http://localhost/project/Website_project_demo/register.php">Register now</a></li>
			</div>
       	    <form action="" method="POST"> 
       		    <input type="name" name="username" placeholder="Username" required /> <br />
       		    <input type="password" name="password" placeholder="Password" required /> <br />
       			<center><input type="submit" value="Submit" name="submit" required /></center>
         	</form>
       </div>	
	
</body>
</html>