
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
		<style type="text/css"> 
	    form{
			width:80%;
			height:auto;
			box-shadow:0 0 5px 1px;
			padding:20px;
			margin:5% auto;
			box-sizing:border-box;
			display:flex;
		}
		.form{
			margin:0 5px;
		}
		input{
			width:100%;
			height:32px;
			margin:10px 0;	
			padding-left:10px;
			box-sizing:border-box;
			}
			h1{
				text-align:center;
			}
			.onheader ul{
	display:flex;
	width:100%;
	background:none;
	height:50px;
	margin-left:-30px;
	border-bottom:1px solid #c3cace;
}
.onheader ul li{
   list-style:none;
   line-height:50px;
   margin-left:30px;
}
.onheader ul li a{
	text-decoration:none;
	color:black;

}
.headierk {
	width:100%;
	height:50px;
	background:#E3F2FD;
}
.headierk p{
	color:black;
	line-height:45px;
	font-size:14px;
	text-align:center;
}		
  @media only screen and (max-width: 600px){
	  	form{
			width:90%;
			display:block;
		}
		.headierk p{
	        color:black;
	        line-height:45px;
	         font-size:12px;
	         text-align:center;
}	
  }

	
	</style>
</head>
<body>
<br />
<div class="onheader"> 
    <ul>
    	<li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard" ><i class="fas fa-home" aria-hidden="true"></i>  ড্যাশবোর্ড </a></li>
    	<li><a href="#" style="color:#007BFF;"><i class="fa fa-laptop" ></i>  নতুন ছাত্র/ছাত্রী যুক্ত করুন  </a></li>
    </ul>
</div>


   
   <?php 
       include "connect.php";
	   if(isset($_POST['submit'])){
		   $add_date=$_POST['add_date'];
		   $birth_date=$_POST['birth_date'];
		   $name=$_POST['name'];
		   $username=$_POST['username'];
		   $file_name=$_FILES['file']['name'];
		   $tmp=$_FILES['file']['tmp_name'];
		   move_uploaded_file($tmp,'img/'.$file_name);
		   $email=$_POST['email'];
		   $rolls=$_POST['roll'];
		   $roll=str_pad($rolls, 2, '0', STR_PAD_LEFT);
		   $father=$_POST['father'];
		   $mother=$_POST['mother'];
		   $phone=$_POST['phone'];
		   $parents_phone=$_POST['parents_phone'];
		   $classs=$_POST['class'];
		    $class=str_pad($classs, 2, '0', STR_PAD_LEFT);
		   $corsce=$_POST['corsce'];
		   $district=$_POST['district'];
		   $thana=$_POST['thana'];
		   $duplicate="SELECT * FROM stuednt_dutb WHERE roll='$roll' AND class='$class'";
		   $duplicate_query=mysqli_query($connect,$duplicate);
		   if(mysqli_num_rows($duplicate_query)==0){
		$insert="INSERT INTO stuednt_dutb(add_date,birth_date,name,username,profile,email,class,roll,mother_name,father_name,phone,parents_phone,course_fee,district,thana)VALUES('$add_date','$birth_date','$name','$username','$file_name','$email','$class','$roll','$mother','$father','$phone','$parents_phone','$corsce','$district','$thana')";
		$query=mysqli_query($connect,$insert);

		
	   }}
   
   ?>
    	 	 	 	 	 	 	 	 	 	



	<form action="" method="POST" enctype= "multipart/form-data">
	    <div class="form"> 
	        <label for="">ভর্তি তারিখ* </label>
               <input type="date" name="add_date" required />
		   <label for="">ছাত্র/ছাত্রী নাম* </label>
               <input type="text" name="name"  required />
			    <label for="">প্রোফাইল ইমেইজ* </label>
               <input type="file" name="file" required   />
	        <label for="">পিতার নাম</label>
               <input type="text" name="father" required  />
			    <label for="">শ্রেনী/ক্লাস</label>
               <input type="text" name="class"required  />	
           <label for="">ফোন</label>
               <input type="text" name="phone" required />			   		
		      <label for="">কোর্স ফি</label>
               <input type="text" name="corsce" required />			   
		     <label for="">থানা</label>
               <input type="text" name="thana"  required/>	      
		</div>    
		 <div class="form">  
            <label for="">জন্ম তারিখ</label>
               <input type="date" name="birth_date" required />	
           <label for="">ছাত্র/ছাত্রী ইউজার নাম* </label>
               <input type="text" name="username" required  />	
          <label for="">ইমেইল(যদি থাকে) </label>
               <input type="email" name="email" required  />			   
	        <label for=""> মাতার নাম</label>
               <input type="text" name="mother" required />	
	        <label for="">রোল নং</label>
               <input type="roll" name="roll"required />		    
	      <label for="">ফোন  (অভিভাবকের)</label>
               <input type="text" name="parents_phone"required  />
		     <label for="">জেলা</label>
               <input type="text" name="district" required />	
			   <label for="" style="color:gray;">Click me</label>
            <input type="submit" value="Submit" name="submit" />			
	     </div>    
	</form>
	
	<br /> <br />
	<div class="headierk"> 
        <p><span style="color:#4463DC;">Student management system /</span> কপিরাইট © 2018- <span style="color:#4463DC;">2022 Soft Host IT /</span>. সর্বস্বত্ব সংরক্ষিত!. গোপনীয়তা এবং শর্তাদি</p>
	</div>
	
	<br /> <br /> 
	
</body>
</html>