
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
	/* bootstrap data tables table customaize */
              .all-student{
              	width:100%;
              	overflow-x:scroll;
              	padding:20px;
              }
              table{
              	min-width:800px;
              	
              }
              table thead:nth-child(1){
              	background:#05566E;
              	max-height:40px !important;
              	color:#fff;
              	text-align:center;
              	
              	font-weight:bold;
              	
              }
              table tbody{
              	text-align:center;
              	line-height:60px;
              
              	
              }
              img{
              	width:80px;
              	height:60px;
              	object-fit:cover;
              }
              td .seemore{
              background:#05566E;
              width:120px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:20px;
              	line-height:40px;
              }
              td .seemore:hover{
              	background:#056480;
              }
			  tr td{
				  font-weight:bold;
			  }
			
		 td .delete{
              background:red;
              width:100px;
              height:40px;
              color:#fff;
              text-decoration:none;
              border-radius:4px;
              display:inline-block;
              	font-size:20px;
              	line-height:40px;
              }
              td .delete:hover{
              	background:#f00c0c;
              }

	</style>
</head>
<body>
<div class="onserve"> 
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
    	    <li><a href="#"  style="color:#007BFF;"><i class="fa fa-laptop"></i>  ছাত্র/ছাত্রী লিস্ট  </a></li>
        </ul>
	</nav>
</div>
<div class="all-student">
<table id="example" class="table table-striped">
        <thead>
			<tr>
				<td>Student Name</td>
				<td>Class</td>
				<td>Roll</td>
				<td>Photo</td>
				<td>See more</td>
				<td>Delete</td>
			</tr>
        </thead>
        <tbody>
		
				<?php
					include "connect.php";
					$select="SELECT * FROM stuednt_dutb";
					$query=mysqli_query($connect,$select);
					while($data=mysqli_fetch_assoc($query)){
						$id=$data['id'];
                        $add_date=$data['add_date'];
		                $birth_date=$data['birth_date'];
		                $name=$data['name'];
		                $username=$data['username'];
		                $profile=$data['profile'];
		                $email=$data['email'];
		                $roll=$data['roll'];
		                $father_name=$data['father_name'];
		                $mother_name=$data['mother_name'];
		                $phone=$data['phone'];
		                $parents_phone=$data['parents_phone'];
		                $classs=$data['class'];
		                $district=$data['district'];
		                $thana=$data['thana'];
						echo "<tr> 
							    <td style='color:#05566E; font-size:20px;'>$name</td>							    
						         <td style='color:#05566E; font-size:20px;'>$classs</td>
								 <td style='color:#05566E; font-size:20px;'>$roll</td>
							    <td><img src='img/$profile' /></td>
							    <td><a href='seemore.php?id=$id' class='seemore'><i class='fa fa-eye'></i> more</a></td>
								<td><a href='delete.php?id=$id' class='delete'>Delete</a></td>
						   </tr>
						";
					}
				?>
        </tbody>
    
    </table>
	</div>
	<br />
	<br />
	<br />
	<br />
		
</body>
</html>