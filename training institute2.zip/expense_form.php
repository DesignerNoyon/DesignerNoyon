
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
<style type="text/css"> 
  	    form{
  			width:400px;
  			height:auto;
  			box-shadow:0 0 5px 1px;
  			padding:20px;
  			margin:5% auto;
  			box-sizing:border-box;
  		}
  		input{
  			width:100%;
  			height:32px;
  			margin:10px 0;	
  			padding-left:10px;
  			box-sizing:border-box;
  		}
    @media only screen and (max-width: 600px){
  	  	form{
  			width:90%;
  			display:block;
  		}	
    }
	 nav ul{
  	     display:flex;
  	     width:100%;
  	     background:none;
  	     height:50px;
  	     margin-left:-30px;
  	     border-bottom:1px solid #c3cace;
    }
  nav ul li{
       list-style:none;
       line-height:50px;
       margin-left:30px;
  }
  nav ul li a{
  	   text-decoration:none;
  	    color:black;
  }
</style>
</head>
<body>
	<br />
   <nav> 
        <ul>
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=dashboard"  style="color:#007BFF;"><i class="fas fa-home" aria-hidden="true"></i> ড্যাশবোর্ড  </a></li>
			
    	    <li><a href="http://localhost/project/Website_project_demo/index.php?page=expense_vouchers"  style="color:#2269B4;"><i class="fa fa-laptop"></i>  খরচের ভাউচার</a></li> 
			
			<li><a href="#"  style="color:black;"><i class="fa fa-laptop"></i>  নতুন খরছ যুক্ত</a></li>
        </ul>
	</nav>
   <?php 
       include "connect.php";
	   if(isset($_POST['result'])){
		   $name=$_POST['name'];
		   $class=$_POST['class'];
		   $roll=$_POST['roll'];
		   $taka=$_POST['taka'];
		   $expense_source=$_POST['expense_source'];
		   $expense_date=$_POST['expense_date'];
		   $insert="INSERT INTO expense(name,class,roll,taka,expense_source,expense_date)VALUES('$name','$class','$roll','$taka','$expense_source','$expense_date')";
		   $query=mysqli_query($connect,$insert);

		
	   }
   
   ?>

	<form action="" method="POST"> 
	    <label for="">Name</label><br />
		  <input type="text" name="name" required /><br />
	    <label for="">Class</label><br />
		  <input type="text" name="class" required /><br />
	    <label for="">Roll</label><br />
		  <input type="text" name="roll" required /><br />
	    <label for="">Taka</label><br />
		  <input type="text" name="taka" required /><br />
		 <label for="">Expense  Source</label><br />
		  <input type="text" name="expense_source" required /><br />
	    <label for="">expense_date</label><br />
		  <input type="date" name="expense_date" required /><br />
		  <input type="submit" value="Result" name="result" />
	</form>
	
	
	
	<br /> <br />
</body>
</html>